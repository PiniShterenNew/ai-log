export interface AiResponse {
    text: string;
    durationMs: number; // milliseconds
}
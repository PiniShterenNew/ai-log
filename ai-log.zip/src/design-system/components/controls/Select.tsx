import * as SelectPrimitive from '../ui/select';

export const Select = SelectPrimitive.Select;
export const SelectGroup = SelectPrimitive.SelectGroup;
export const SelectValue = SelectPrimitive.SelectValue;
export const SelectTrigger = SelectPrimitive.SelectTrigger;
export const SelectContent = SelectPrimitive.SelectContent;
export const SelectLabel = SelectPrimitive.SelectLabel;
export const SelectItem = SelectPrimitive.SelectItem;
export const SelectSeparator = SelectPrimitive.SelectSeparator;
export const SelectScrollUpButton = SelectPrimitive.SelectScrollUpButton;
export const SelectScrollDownButton = SelectPrimitive.SelectScrollDownButton;

